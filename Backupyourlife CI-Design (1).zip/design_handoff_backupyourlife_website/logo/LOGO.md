# Logo 2e – „Großes b, kleines b mit Marker"

**Idee:** Ein großes b (Elternteil) und ein kleines, angelehntes b (Kind) stehen gemeinsam auf einem Textmarker-Strich. Wir sichern ab, nicht für uns, sondern für unsere Kinder. Lesbar auch als „Plan b".

## Dateien
| Datei | Einsatz |
|---|---|
| `logo-light.svg` | Standard auf Weiß (Header, Print) |
| `logo-dark.svg` | Auf #1A1A1A (Footer, dunkle Flächen) |
| `logo-mono-black.svg` | Einfarbig für Stempel, Fax, Gravur |
| `icon-app.svg` | App-Icon, Social-Avatar (512 px, gerundet) |
| `favicon.svg` | Favicon (eckig, Browser rundet selbst) |
| `Logo.tsx` | React-Komponente: `<Logo variant="light|dark|mono" height={40} symbolOnly />` |

## Aufbau
- Bildzeichen: großes **b** (Caveat Brush, 100 %) + kleines **b** (54 %, um +6° gedreht, überlappt leicht)
- Marker: gerundetes Rechteck hinter der unteren Hälfte beider b, −1° gedreht
- Wortmarke: „backup / yourlife" zweizeilig, Caveat Brush, 40 % der b-Höhe, Grundlinie bündig mit dem Bildzeichen

## Farben
| | Hell | Dunkel |
|---|---|---|
| Großes b | #1A1A1A | #FFFFFF |
| Kleines b | #2B59C3 | #FFC531 |
| Marker | #FFC531 | #E8412C |
| Wortmarke | #1A1A1A | #FFFFFF |

## Regeln
- Schutzraum: Höhe des kleinen b rundum
- Mindesthöhe: 28 px digital / 10 mm Print. Darunter nur das Bildzeichen (`symbolOnly`).
- Header 40 px hoch, Footer 56 px
- Nicht: Farben tauschen, kleines b gerade stellen, Marker weglassen, Schatten oder Verläufe ergänzen

## Wichtig vor Go-live
Die SVGs nutzen die Schrift Caveat Brush als Text (per Google-Fonts-Import). Für die finale Fassung **Text in Pfade umwandeln** (z. B. Figma/Illustrator „Outline", oder `opentype.js`), damit das Logo ohne Webfont überall identisch aussieht. Für Print zusätzlich PDF/EPS exportieren.
