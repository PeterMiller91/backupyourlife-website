// backupyourlife Logo 2e – "Großes b, kleines b mit Marker"
// Benötigt Caveat Brush (next/font/google oder <link> in <head>).
type Variant = 'light' | 'dark' | 'mono';
const C = {
  light: { marker: '#FFC531', big: '#1A1A1A', small: '#2B59C3', word: '#1A1A1A' },
  dark:  { marker: '#E8412C', big: '#FFFFFF', small: '#FFC531', word: '#FFFFFF' },
  mono:  { marker: '#FFC531', big: '#1A1A1A', small: '#1A1A1A', word: '#1A1A1A' },
};
export function Logo({ variant = 'light', height = 40, symbolOnly = false }: { variant?: Variant; height?: number; symbolOnly?: boolean }) {
  const c = C[variant];
  const w = symbolOnly ? 104 : 270;
  return (
    <svg viewBox={`0 0 ${w} 120`} height={height} role="img" aria-label="backupyourlife" style={{ fontFamily: "'Caveat Brush', cursive" }}>
      <rect x="2" y="66" width="96" height="36" rx="5" fill={c.marker} transform="rotate(-1 50 84)" />
      <text x="10" y="104" fontSize="100" fill={c.big}>b</text>
      <text x="58" y="104" fontSize="54" fill={c.small} transform="rotate(6 70 90)">b</text>
      {!symbolOnly && (<>
        <text x="112" y="72" fontSize="40" fill={c.word}>backup</text>
        <text x="112" y="106" fontSize="40" fill={c.word}>yourlife</text>
      </>)}
    </svg>
  );
}
